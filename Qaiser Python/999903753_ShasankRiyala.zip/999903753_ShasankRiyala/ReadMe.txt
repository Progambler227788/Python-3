First of all place all files inside one folder. Then, open this folder in your IDE like pycharm, vscode or any other
IDE. Make sure index.html is also in same folder. 

1. Open web_server.py file. Run it. It will show Server running on port 8080. Then, open http://localhost:8080 on your
default web browser like Chrome, Edge, FireFox. Refresh it 2-3 times to see output in terminal.
2. Open web_client.py file. Run it, input server IP (localhost), server port (8080), and file name that is 
index.html. Just refresh your page localhost:8080 one or two time for avoiding any delay. 
3. After this, it will download file in your current directory in which your .py files will be. Downloaded file
name will be downloaded_file.html having content of index.html
4. Successfully tested. Run it for multiple clients after refreshing page. It will work fine.